public abstract class Gadget extends Entity {
    protected String description;

    public Gadget(String name, String id, String description) {
        super(name, id);
        this.description = description;
    }

    public static int getGadgetsBonus() {
        return 500;
    }

    public String getID() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public void attributes() {
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Description: " + getDescription());
    }
}




