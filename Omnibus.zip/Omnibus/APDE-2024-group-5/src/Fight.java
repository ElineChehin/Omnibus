public abstract class Fight {

    protected Hero hero;
    protected Villain villain;

    public Fight() {
    }
    public ComicCharacter getHero() {
        return hero;
    }

    public ComicCharacter getVillain() {
        return villain;
    }
}