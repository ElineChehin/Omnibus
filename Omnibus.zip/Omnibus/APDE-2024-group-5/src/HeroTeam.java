public class HeroTeam extends Team {

    public HeroTeam(String name, String id) {
        super(name, id);
    }

    public void addHero(Hero hero) {
        addMember(hero);
    }
}
