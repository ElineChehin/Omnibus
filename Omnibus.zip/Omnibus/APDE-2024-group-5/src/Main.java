import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<ComicCharacter> characterList = new ArrayList<>();
        List<Entity> fanList = new ArrayList<>();
        List<Team> teamList = new ArrayList<>();

        // Heroes
        Hero superman = new Hero("Superman", "H-1", "Metropolis", "I'm the man of Steel!", "Lex Luthor, General Zod and Brainiac.", 800, "Clark Kent (Kal-El)", "Lex Luthor");
        superman.setArchEnemy("Lex Luthor");
        characterList.add(superman);

        Hero batman = new Hero("Batman", "H-2", "Gotham City", "I'm the night, I'm Batman!", "The Joker, Two-Face and The Riddler.", 900, "Bruce Wayne", "The Joker");
        batman.setArchEnemy("The Joker");
        characterList.add(batman);

        Hero spiderMan = new Hero("Spider-Man", "H-3", "New York City", "With great power comes great responsibility!", "Carnage, Doctor Octopus and Venom.", 750, "Peter Parker", "Carnage");
        spiderMan.setArchEnemy("Carnage");
        characterList.add(spiderMan);

        Hero thor = new Hero("Thor", "H-4", "Asgard", "I am the god of thunder!", "Loki, Hela and Malekith.", 850, "Thor Odinson", "Loki");
        thor.setArchEnemy("Loki");
        characterList.add(thor);

        Hero mrFantastic = new Hero("Mr. Fantastic", "H-5", "New York City", "I stretch my abilities to help mankind!", "Doctor Doom, Annihilus and Mole Man.", 780, "Reed Richards", "Doctor Doom");
        mrFantastic.setArchEnemy("Doctor Doom");
        characterList.add(mrFantastic);

        Hero greenLantern = new Hero("Green Lantern", "H-6", "Coast City", "In brightest day, in blackest night, no evil shall escape my sight!", "Sinestro, Atrocitus and Parallax.", 820, "Hal Jordan", "Sinestro");
        greenLantern.setArchEnemy("Sinestro");
        characterList.add(greenLantern);

        Hero greenArrow = new Hero("Green Arrow", "H-7", "Star City", "I fight for justice with my bow and arrow!", "Malcolm Merlyn, Deathstroke and Count Vertigo.", 760, "Oliver Queen", "Malcolm Merlyn");
        greenArrow.setArchEnemy("Malcolm Merlyn");
        characterList.add(greenArrow);

        Hero wonderWoman = new Hero("Wonder Woman", "H-8", "Themyscira", "I am an Amazonian warrior fighting for peace!", "Ares, Cheetah and Circe.", 830, "Diana Prince", "Ares");
        wonderWoman.setArchEnemy("Ares");
        characterList.add(wonderWoman);

        Hero supergirl = new Hero("Supergirl", "H-9", "National City", "I am the Girl of Steel!", "Lex Luthor, Siobhan McDougal and Bizarro.", 780, "Kara Zor-El", "Siobhan McDougal");
        supergirl.setArchEnemy("Siobhan McDougal");
        characterList.add(supergirl);

        Hero batgirl = new Hero("Batgirl", "H-10", "Gotham City", "I fight to protect Gotham!", "The Joker, Firefly and Harley Quinn.", 770, "Barbara Gordon", "Firefly");
        batgirl.setArchEnemy("Firefly");
        characterList.add(batgirl);

        Hero captainAmerica = new Hero("Captain America", "H-11", "New York City", "I fight for the American Dream!", "Red Skull, Winter Soldier and Baron Zemo.", 840, "Steve Rogers", "Red Skull");
        captainAmerica.setArchEnemy("Red Skull");
        characterList.add(captainAmerica);

        Hero captainMarvel = new Hero("Captain Marvel", "H-12", "Earth", "I am the protector of the universe!", "Yon-Rogg and Supreme Intelligence.", 870, "Carol Danvers", "Yon-Rogg");
        captainMarvel.setArchEnemy("Yon-Rogg");
        characterList.add(captainMarvel);

        Hero aquaman = new Hero("Aquaman", "H-13", "Atlantis", "I am the king of the seven seas!", "Black Manta, Ocean Master and King Shark.", 790, "Arthur Curry", "Black Manta");
        aquaman.setArchEnemy("Black Manta");
        characterList.add(aquaman);

        Hero theFlash = new Hero("The Flash", "H-14", "Central City", "I am the fastest man alive!", "Reverse-Flash, Zoom and Gorilla Grodd.", 820, "Barry Allen", "Reverse-Flash");
        theFlash.setArchEnemy("Reverse-Flash");
        characterList.add(theFlash);

        Hero blackPanther = new Hero("Black Panther", "H-15", "Wakanda", "I am the protector of Wakanda!", "Killmonger, Klaw and Man-Ape.", 830, "T'Challa", "Killmonger");
        blackPanther.setArchEnemy("Killmonger");
        characterList.add(blackPanther);

        Hero ironMan = new Hero("Iron Man", "H-16", "New York City", "I am Iron Man!", "Mandarin, Obadiah Stane and Ultron.", 860, "Tony Stark", "Mandarin");
        ironMan.setArchEnemy("Mandarin");
        characterList.add(ironMan);

        Hero catwoman = new Hero("Catwoman", "H-17", "Gotham City", "I am the feline fatale!", "Batman, Black Mask and Bane.", 750, "Selina Kyle", "Black Mask");
        catwoman.setArchEnemy("Black Mask");
        characterList.add(catwoman);

        Hero wolverine = new Hero("Wolverine", "H-18", "Canada", "I am the best there is at what I do!", "Sabretooth, Magneto and Lady Deathstrike.", 840, "Logan", "Sabretooth");
        wolverine.setArchEnemy("Sabretooth");
        characterList.add(wolverine);

        Hero hawkeye = new Hero("Hawkeye", "H-19", "New York City", "I never miss my target!", "Bullseye and Crossfire.", 760, "Clint Barton", "Crossfire");
        hawkeye.setArchEnemy("Crossfire");
        characterList.add(hawkeye);

        Hero daredevil = new Hero("Daredevil", "H-20", "New York City", "I fight for justice in Hell's Kitchen!", "Kingpin, Bullseye and Elektra.", 780, "Matt Murdock", "Kingpin");
        daredevil.setArchEnemy("Kingpin");
        characterList.add(daredevil);

        //Villains
        Villain lexLuthor = new Villain("Lex Luthor", "V-1", "Metropolis", "You can't beat me!", "Superman and Justice League", 850, "Superman", "Rule the world");
        lexLuthor.setArchEnemy("Superman");
        characterList.add(lexLuthor);

        Villain theJoker = new Villain("The Joker", "V-2", "Gotham City", "Why so serious?", "Batman and the Gotham City Police Department", 700, "Batman", "Spread chaos!");
        theJoker.setArchEnemy("Batman");
        characterList.add(theJoker);

        Villain carnage = new Villain("Carnage", "V-3", "New York City", "Chaos is my nature!", "Spider-Man and Venom", 820, "Spider-Man", "Create mayhem");
        carnage.setArchEnemy("Spider-Man");
        characterList.add(carnage);

        Villain loki = new Villain("Loki", "V-4", "Asgard", "I'm burdened with glorious purpose!", "Thor and The Avengers", 890, "Thor", "Conquer Asgard");
        loki.setArchEnemy("Thor");
        characterList.add(loki);

        Villain doctorDoom = new Villain("Doctor Doom", "V-5", "Latveria", "Bow before Doom!", "Fantastic Four and Spider-Man", 870, "Mr. Fantastic", "Rule with iron fist");
        doctorDoom.setArchEnemy("Mr. Fantastic");
        characterList.add(doctorDoom);

        Villain sinestro = new Villain("Sinestro", "V-6", "Korugar", "Fear will be your downfall!", "Green Lantern Corps and Superman", 840, "Green Lantern", "Enforce order");
        sinestro.setArchEnemy("Green Lantern");
        characterList.add(sinestro);

        Villain malcolmMerlyn = new Villain("Malcolm Merlyn", "V-7", "Starling City", "I am the dark archer!", "Green Arrow and Team Arrow", 760, "Green Arrow", "Achieve power");
        malcolmMerlyn.setArchEnemy("Green Arrow");
        characterList.add(malcolmMerlyn);

        Villain ares = new Villain("Ares", "V-8", "Mount Olympus", "I crave for war!", "Wonder Woman and Batgirl", 830, "Wonder Woman", "Instigate conflicts");
        ares.setArchEnemy("Wonder Woman");
        characterList.add(ares);

        Villain siobhanMcDougal = new Villain("Siobhan McDougal", "V-9", "Ireland", "I am the Silver Banshee!", "Supergirl and Superman", 780, "Supergirl", "Seek revenge");
        siobhanMcDougal.setArchEnemy("Supergirl");
        characterList.add(siobhanMcDougal);

        Villain firefly = new Villain("Firefly", "V-10", "Gotham City", "I will burn everything!", "Batgirl, Batman and the Gotham City Police Department", 740, "Batgirl", "Set everything ablaze");
        firefly.setArchEnemy("Batgirl");
        characterList.add(firefly);

        Villain redSkull = new Villain("Red Skull", "V-11", "Germany", "Hail Hydra!", "Captain America and the Avengers", 860, "Captain America", "Dominate the world");
        redSkull.setArchEnemy("Captain America");
        characterList.add(redSkull);

        Villain yonRogg = new Villain("Yon-Rogg", "V-12", "Hala", "I am superior!", "Captain Marvel and Captain America", 820, "Captain Marvel", "Defeat the Kree enemies");
        yonRogg.setArchEnemy("Captain Marvel");
        characterList.add(yonRogg);

        Villain blackManta = new Villain("Black Manta", "V-13", "Atlantis", "I will drown the world!", "Aquaman and Spider-Man", 790, "Aquaman", "Seek vengeance");
        blackManta.setArchEnemy("Aquaman");
        characterList.add(blackManta);

        Villain theReverseFlash = new Villain("The Reverse Flash", "V-14", "Central City", "I am the reverse!", "The Flash and Spider-Man", 850, "The Flash", "Destroy Flash's legacy");
        theReverseFlash.setArchEnemy("The Flash");
        characterList.add(theReverseFlash);

        Villain killmonger = new Villain("Killmonger", "V-15", "Wakanda", "Death is better than bondage!", "Black Panther and Superman", 830, "Black Panther", "Overthrow Wakanda");
        killmonger.setArchEnemy("Black Panther");
        characterList.add(killmonger);

        Villain theMandarin = new Villain("The Mandarin", "V-16", "China", "I possess the rings of power!", "Iron Man and Batman", 870, "Iron Man", "Conquer the world");
        theMandarin.setArchEnemy("Iron Man");
        characterList.add(theMandarin);

        Villain blackMask = new Villain("Black Mask", "V-17", "Gotham City", "I control Gotham's underworld!", "Catwoman and the Gotham City Police Department", 760, "Catwoman", "Establish dominance");
        blackMask.setArchEnemy("Catwoman");
        characterList.add(blackMask);

        Villain sabretooth = new Villain("Sabretooth", "V-18", "Canada", "I am the ultimate predator!", "Wolverine and X-Men", 840, "Wolverine", "Prove superiority");
        sabretooth.setArchEnemy("Wolverine");
        characterList.add(sabretooth);

        Villain crossfire = new Villain("Crossfire", "V-19", "New York City", "My aim is to kill!", "Hawkeye and Superman", 770, "Hawkeye", "Create chaos");
        crossfire.setArchEnemy("Hawkeye");
        characterList.add(crossfire);

        Villain kingpin = new Villain("Kingpin", "V-20", "New York City", "I control everything!", "Daredevil and Spider-Man", 850, "Daredevil", "Expand criminal empire");
        kingpin.setArchEnemy("Daredevil");
        characterList.add(kingpin);

        // Fans
        Fan fan1 = new Fan("Finn Peterson", "FL-1000");
        superman.myListOfFans.add(fan1);
        batman.myListOfFans.add(fan1);
        kingpin.myListOfFans.add(fan1);
        crossfire.myListOfFans.add(fan1);
        fanList.add(fan1);

        Fan fan2 = new Fan("Emily Martinez", "FL-1001");
        killmonger.myListOfFans.add(fan2);
        firefly.myListOfFans.add(fan2);
        ares.myListOfFans.add(fan2);
        lexLuthor.myListOfFans.add(fan2);
        thor.myListOfFans.add(fan2);
        fanList.add(fan2);

        Fan fan3 = new Fan("Noah Thompson", "FL-1002");
        lexLuthor.myListOfFans.add(fan3);
        theJoker.myListOfFans.add(fan3);
        theReverseFlash.myListOfFans.add(fan3);
        batgirl.myListOfFans.add(fan3);
        greenArrow.myListOfFans.add(fan3);
        fanList.add(fan3);

        Fan fan4 = new Fan("Olivia Johnson", "FL-1003");
        superman.myListOfFans.add(fan4);
        theJoker.myListOfFans.add(fan4);
        spiderMan.myListOfFans.add(fan4);
        thor.myListOfFans.add(fan4);
        supergirl.myListOfFans.add(fan4);
        fanList.add(fan4);

        Fan fan5 = new Fan("Ethan Williams", "FL-1004");
        lexLuthor.myListOfFans.add(fan5);
        superman.myListOfFans.add(fan5);
        doctorDoom.myListOfFans.add(fan5);
        killmonger.myListOfFans.add(fan5);
        mrFantastic.myListOfFans.add(fan5);
        daredevil.myListOfFans.add(fan5);
        loki.myListOfFans.add(fan5);
        fanList.add(fan5);

        Fan fan6 = new Fan("Ava Garcia", "FL-1005");
        superman.myListOfFans.add(fan6);
        lexLuthor.myListOfFans.add(fan6);
        carnage.myListOfFans.add(fan6);
        catwoman.myListOfFans.add(fan6);
        supergirl.myListOfFans.add(fan6);
        fanList.add(fan6);

        Fan fan7 = new Fan("Mason Smith", "FL-1006");
        batman.myListOfFans.add(fan7);
        theJoker.myListOfFans.add(fan7);
        wolverine.myListOfFans.add(fan7);
        hawkeye.myListOfFans.add(fan7);
        malcolmMerlyn.myListOfFans.add(fan7);
        blackManta.myListOfFans.add(fan7);
        blackMask.myListOfFans.add(fan7);
        fanList.add(fan7);

        Fan fan8 = new Fan("Isabella Hernandez", "FL-1007");
        lexLuthor.myListOfFans.add(fan8);
        theJoker.myListOfFans.add(fan8);
        theMandarin.myListOfFans.add(fan8);
        kingpin.myListOfFans.add(fan8);
        wonderWoman.myListOfFans.add(fan8);
        fanList.add(fan8);

        Fan fan9 = new Fan("Logan Brown", "FL-1008");
        superman.myListOfFans.add(fan9);
        batman.myListOfFans.add(fan9);
        lexLuthor.myListOfFans.add(fan9);
        sabretooth.myListOfFans.add(fan9);
        theFlash.myListOfFans.add(fan9);
        greenArrow.myListOfFans.add(fan9);
        fanList.add(fan9);

        Fan fan10 = new Fan("Sophia Lopez", "FL-1009");
        theJoker.myListOfFans.add(fan10);
        lexLuthor.myListOfFans.add(fan10);
        sinestro.myListOfFans.add(fan10);
        siobhanMcDougal.myListOfFans.add(fan10);
        blackManta.myListOfFans.add(fan10);
        redSkull.myListOfFans.add(fan10);
        killmonger.myListOfFans.add(fan10);
        supergirl.myListOfFans.add(fan10);
        spiderMan.myListOfFans.add(fan10);
        fanList.add(fan10);

        Fan fan11 = new Fan("Lucas Lee", "FL-1010");
        mrFantastic.myListOfFans.add(fan11);
        lexLuthor.myListOfFans.add(fan11);
        malcolmMerlyn.myListOfFans.add(fan11);
        blackManta.myListOfFans.add(fan11);
        siobhanMcDougal.myListOfFans.add(fan11);
        fanList.add(fan11);

        Fan fan12 = new Fan("Mia Perez", "FL-1011");
        batman.myListOfFans.add(fan12);
        lexLuthor.myListOfFans.add(fan12);
        crossfire.myListOfFans.add(fan12);
        blackPanther.myListOfFans.add(fan12);
        wonderWoman.myListOfFans.add(fan12);
        thor.myListOfFans.add(fan12);
        mrFantastic.myListOfFans.add(fan12);
        fanList.add(fan12);

        Fan fan13 = new Fan("Jackson Miller", "FL-1012");
        batman.myListOfFans.add(fan13);
        theJoker.myListOfFans.add(fan13);
        batgirl.myListOfFans.add(fan13);
        wolverine.myListOfFans.add(fan13);
        sinestro.myListOfFans.add(fan13);
        captainAmerica.myListOfFans.add(fan13);
        fanList.add(fan13);

        Fan fan14 = new Fan("Charlotte Gonzalez", "FL-1013");
        batman.myListOfFans.add(fan14);
        lexLuthor.myListOfFans.add(fan14);
        carnage.myListOfFans.add(fan14);
        hawkeye.myListOfFans.add(fan14);
        supergirl.myListOfFans.add(fan14);
        catwoman.myListOfFans.add(fan14);
        fanList.add(fan14);

        Fan fan15 = new Fan("Aiden Davis", "FL-1014");
        theJoker.myListOfFans.add(fan15);
        superman.myListOfFans.add(fan15);
        redSkull.myListOfFans.add(fan15);
        captainAmerica.myListOfFans.add(fan15);
        captainMarvel.myListOfFans.add(fan15);
        sinestro.myListOfFans.add(fan15);
        wolverine.myListOfFans.add(fan15);
        fanList.add(fan15);

        Fan fan16 = new Fan("Harper Wilson", "FL-1015");
        lexLuthor.myListOfFans.add(fan16);
        theJoker.myListOfFans.add(fan16);
        aquaman.myListOfFans.add(fan16);
        doctorDoom.myListOfFans.add(fan16);
        firefly.myListOfFans.add(fan16);
        fanList.add(fan16);

        Fan fan17 = new Fan("Elijah Anderson", "FL-1016");
        superman.myListOfFans.add(fan17);
        theJoker.myListOfFans.add(fan17);
        theMandarin.myListOfFans.add(fan17);
        theReverseFlash.myListOfFans.add(fan17);
        batgirl.myListOfFans.add(fan17);
        wolverine.myListOfFans.add(fan17);
        aquaman.myListOfFans.add(fan17);
        fanList.add(fan17);

        Fan fan18 = new Fan("Amelia Taylor", "FL-1017");
        batman.myListOfFans.add(fan18);
        lexLuthor.myListOfFans.add(fan18);
        batman.myListOfFans.add(fan18);
        blackPanther.myListOfFans.add(fan18);
        loki.myListOfFans.add(fan18);
        killmonger.myListOfFans.add(fan18);
        thor.myListOfFans.add(fan18);
        blackManta.myListOfFans.add(fan18);
        fanList.add(fan18);

        Fan fan19 = new Fan("Grayson Thomas", "FL-1018");
        theJoker.myListOfFans.add(fan19);
        ares.myListOfFans.add(fan19);
        captainAmerica.myListOfFans.add(fan19);
        greenLantern.myListOfFans.add(fan19);
        sinestro.myListOfFans.add(fan19);
        spiderMan.myListOfFans.add(fan19);
        kingpin.myListOfFans.add(fan19);
        fanList.add(fan19);

        Fan fan20 = new Fan("Evelyn Moore", "FL-1019");
        batman.myListOfFans.add(fan20);
        loki.myListOfFans.add(fan20);
        daredevil.myListOfFans.add(fan20);
        blackManta.myListOfFans.add(fan20);
        sabretooth.myListOfFans.add(fan20);
        mrFantastic.myListOfFans.add(fan20);
        aquaman.myListOfFans.add(fan20);
        fanList.add(fan20);

        Fan fan21 = new Fan("Carter Jackson", "FL-1020");
        lexLuthor.myListOfFans.add(fan21);
        batman.myListOfFans.add(fan21);
        wolverine.myListOfFans.add(fan21);
        ares.myListOfFans.add(fan21);
        theReverseFlash.myListOfFans.add(fan21);
        crossfire.myListOfFans.add(fan21);
        wonderWoman.myListOfFans.add(fan21);
        thor.myListOfFans.add(fan21);
        fanList.add(fan21);

        Fan fan22 = new Fan("Abigail Martin", "FL-1021");
        batgirl.myListOfFans.add(fan22);
        daredevil.myListOfFans.add(fan22);
        ironMan.myListOfFans.add(fan22);
        captainAmerica.myListOfFans.add(fan22);
        batman.myListOfFans.add(fan22);
        sinestro.myListOfFans.add(fan22);
        fanList.add(fan22);

        Fan fan23 = new Fan("Owen White", "FL-1022");
        superman.myListOfFans.add(fan23);
        ares.myListOfFans.add(fan23);
        doctorDoom.myListOfFans.add(fan23);
        sabretooth.myListOfFans.add(fan23);
        lexLuthor.myListOfFans.add(fan23);
        supergirl.myListOfFans.add(fan23);
        theMandarin.myListOfFans.add(fan23);
        blackManta.myListOfFans.add(fan23);
        blackMask.myListOfFans.add(fan23);
        fanList.add(fan23);

        Fan fan24 = new Fan("Elizabeth Lewis", "FL-1023");
        yonRogg.myListOfFans.add(fan24);
        loki.myListOfFans.add(fan24);
        carnage.myListOfFans.add(fan24);
        catwoman.myListOfFans.add(fan24);
        ironMan.myListOfFans.add(fan24);
        wonderWoman.myListOfFans.add(fan24);
        lexLuthor.myListOfFans.add(fan24);
        thor.myListOfFans.add(fan24);
        spiderMan.myListOfFans.add(fan24);
        batman.myListOfFans.add(fan24);
        fanList.add(fan24);

        Fan fan25 = new Fan("Caleb Clark", "FL-1024");
        superman.myListOfFans.add(fan25);
        theJoker.myListOfFans.add(fan25);
        ares.myListOfFans.add(fan25);
        hawkeye.myListOfFans.add(fan25);
        aquaman.myListOfFans.add(fan25);
        ironMan.myListOfFans.add(fan25);
        blackPanther.myListOfFans.add(fan25);
        fanList.add(fan25);

        Fan fan26 = new Fan("Ella Hill", "FL-1025");
        theJoker.myListOfFans.add(fan26);
        daredevil.myListOfFans.add(fan26);
        carnage.myListOfFans.add(fan26);
        wonderWoman.myListOfFans.add(fan26);
        batgirl.myListOfFans.add(fan26);
        batman.myListOfFans.add(fan26);
        spiderMan.myListOfFans.add(fan26);
        blackManta.myListOfFans.add(fan26);
        firefly.myListOfFans.add(fan26);
        fanList.add(fan26);

        Fan fan27 = new Fan("Samuel Hall", "FL-1026");
        lexLuthor.myListOfFans.add(fan27);
        wolverine.myListOfFans.add(fan27);
        aquaman.myListOfFans.add(fan27);
        ironMan.myListOfFans.add(fan27);
        theFlash.myListOfFans.add(fan27);
        thor.myListOfFans.add(fan27);
        aquaman.myListOfFans.add(fan27);
        batgirl.myListOfFans.add(fan27);
        superman.myListOfFans.add(fan27);
        fanList.add(fan27);

        Fan fan28 = new Fan("Avery Young", "FL-1027");
        theJoker.myListOfFans.add(fan28);
        daredevil.myListOfFans.add(fan28);
        ares.myListOfFans.add(fan28);
        supergirl.myListOfFans.add(fan28);
        loki.myListOfFans.add(fan28);
        crossfire.myListOfFans.add(fan28);
        batman.myListOfFans.add(fan28);
        fanList.add(fan28);

        Fan fan29 = new Fan("Benjamin Allen", "FL-1028");
        lexLuthor.myListOfFans.add(fan29);
        killmonger.myListOfFans.add(fan29);
        carnage.myListOfFans.add(fan29);
        wolverine.myListOfFans.add(fan29);
        superman.myListOfFans.add(fan29);
        redSkull.myListOfFans.add(fan29);
        fanList.add(fan29);

        Fan fan30 = new Fan("Grace Scott", "FL-1029");
        superman.myListOfFans.add(fan30);
        kingpin.myListOfFans.add(fan30);
        crossfire.myListOfFans.add(fan30);
        yonRogg.myListOfFans.add(fan30);
        malcolmMerlyn.myListOfFans.add(fan30);
        loki.myListOfFans.add(fan30);
        ironMan.myListOfFans.add(fan30);
        theJoker.myListOfFans.add(fan30);
        fanList.add(fan30);

        Fan fan31 = new Fan("Henry King", "FL-1030");
        sinestro.myListOfFans.add(fan31);
        theJoker.myListOfFans.add(fan31);
        doctorDoom.myListOfFans.add(fan31);
        loki.myListOfFans.add(fan31);
        carnage.myListOfFans.add(fan31);
        blackPanther.myListOfFans.add(fan31);
        supergirl.myListOfFans.add(fan31);
        fanList.add(fan31);

        Fan fan32 = new Fan("Scarlett Green", "FL-1031");
        lexLuthor.myListOfFans.add(fan32);
        superman.myListOfFans.add(fan32);
        theJoker.myListOfFans.add(fan32);
        daredevil.myListOfFans.add(fan32);
        carnage.myListOfFans.add(fan32);
        wolverine.myListOfFans.add(fan32);
        aquaman.myListOfFans.add(fan32);
        mrFantastic.myListOfFans.add(fan32);
        superman.myListOfFans.add(fan32);
        firefly.myListOfFans.add(fan32);
        fanList.add(fan32);

        Fan fan33 = new Fan("Gabriel Baker", "FL-1032");
        theJoker.myListOfFans.add(fan33);
        lexLuthor.myListOfFans.add(fan33);
        hawkeye.myListOfFans.add(fan33);
        aquaman.myListOfFans.add(fan33);
        batgirl.myListOfFans.add(fan33);
        hawkeye.myListOfFans.add(fan33);
        spiderMan.myListOfFans.add(fan33);
        fanList.add(fan33);

        Fan fan34 = new Fan("Chloe Adams", "FL-1033");
        theJoker.myListOfFans.add(fan34);
        lexLuthor.myListOfFans.add(fan34);
        kingpin.myListOfFans.add(fan34);
        firefly.myListOfFans.add(fan34);
        doctorDoom.myListOfFans.add(fan34);
        blackMask.myListOfFans.add(fan34);
        wolverine.myListOfFans.add(fan34);
        batgirl.myListOfFans.add(fan34);
        thor.myListOfFans.add(fan34);
        aquaman.myListOfFans.add(fan34);
        fanList.add(fan34);

        Fan fan35 = new Fan("Wyatt Nelson", "FL-1034");
        lexLuthor.myListOfFans.add(fan35);
        theJoker.myListOfFans.add(fan35);
        blackManta.myListOfFans.add(fan35);
        blackMask.myListOfFans.add(fan35);
        fanList.add(fan35);

        Fan fan36 = new Fan("Zoey Carter", "FL-1035");
        theJoker.myListOfFans.add(fan36);
        lexLuthor.myListOfFans.add(fan36);
        ares.myListOfFans.add(fan36);
        firefly.myListOfFans.add(fan36);
        fanList.add(fan36);

        Fan fan37 = new Fan("Isaac Mitchell", "FL-1036");
        theJoker.myListOfFans.add(fan37);
        lexLuthor.myListOfFans.add(fan37);
        catwoman.myListOfFans.add(fan37);
        malcolmMerlyn.myListOfFans.add(fan37);
        fanList.add(fan37);

        Fan fan38 = new Fan("Lily Roberts", "FL-1037");
        theJoker.myListOfFans.add(fan38);
        superman.myListOfFans.add(fan38);
        crossfire.myListOfFans.add(fan38);
        supergirl.myListOfFans.add(fan38);
        fanList.add(fan38);

        Fan fan39 = new Fan("Julian Rivera", "FL-1038");
        lexLuthor.myListOfFans.add(fan39);
        theJoker.myListOfFans.add(fan39);
        thor.myListOfFans.add(fan39);
        greenArrow.myListOfFans.add(fan39);
        greenLantern.myListOfFans.add(fan39);
        ironMan.myListOfFans.add(fan39);
        fanList.add(fan39);

        Fan fan40 = new Fan("Layla Phillips", "FL-1039");
        lexLuthor.myListOfFans.add(fan40);
        batman.myListOfFans.add(fan40);
        catwoman.myListOfFans.add(fan40);
        sabretooth.myListOfFans.add(fan40);
        wolverine.myListOfFans.add(fan40);
        hawkeye.myListOfFans.add(fan40);
        batgirl.myListOfFans.add(fan40);
        thor.myListOfFans.add(fan40);
        fanList.add(fan40);

        Fan fan41 = new Fan("Christopher Campbell", "FL-1040");
        theJoker.myListOfFans.add(fan41);
        killmonger.myListOfFans.add(fan41);
        catwoman.myListOfFans.add(fan41);
        greenArrow.myListOfFans.add(fan41);
        supergirl.myListOfFans.add(fan41);
        wolverine.myListOfFans.add(fan41);
        fanList.add(fan41);

        Fan fan42 = new Fan("Natalie Evans", "FL-1041");
        theJoker.myListOfFans.add(fan42);
        lexLuthor.myListOfFans.add(fan42);
        kingpin.myListOfFans.add(fan42);
        fanList.add(fan42);

        Fan fan43 = new Fan("Andrew Cook", "FL-1042");
        superman.myListOfFans.add(fan43);
        mrFantastic.myListOfFans.add(fan43);
        daredevil.myListOfFans.add(fan43);
        catwoman.myListOfFans.add(fan43);
        firefly.myListOfFans.add(fan43);
        fanList.add(fan43);

        Fan fan44 = new Fan("Victoria Stewart", "FL-1043");
        superman.myListOfFans.add(fan44);
        batman.myListOfFans.add(fan44);
        sinestro.myListOfFans.add(fan44);
        theFlash.myListOfFans.add(fan44);
        theJoker.myListOfFans.add(fan44);
        batgirl.myListOfFans.add(fan44);
        greenArrow.myListOfFans.add(fan44);
        fanList.add(fan44);

        Fan fan45 = new Fan("Joshua Morris", "FL-1044");
        lexLuthor.myListOfFans.add(fan45);
        catwoman.myListOfFans.add(fan45);
        aquaman.myListOfFans.add(fan45);
        batman.myListOfFans.add(fan45);
        fanList.add(fan45);

        Fan fan46 = new Fan("Addison Sanchez", "FL-1045");
        theJoker.myListOfFans.add(fan46);
        lexLuthor.myListOfFans.add(fan46);
        redSkull.myListOfFans.add(fan46);
        yonRogg.myListOfFans.add(fan46);
        fanList.add(fan46);

        Fan fan47 = new Fan("David Price", "FL-1046");
        theJoker.myListOfFans.add(fan47);
        batman.myListOfFans.add(fan47);
        carnage.myListOfFans.add(fan47);
        wolverine.myListOfFans.add(fan47);
        fanList.add(fan47);

        Fan fan48 = new Fan("Brooklyn Ramirez", "FL-1047");
        theJoker.myListOfFans.add(fan48);
        superman.myListOfFans.add(fan48);
        daredevil.myListOfFans.add(fan48);
        firefly.myListOfFans.add(fan48);
        fanList.add(fan48);

        Fan fan49 = new Fan("Joseph Ward", "FL-1048");
        theJoker.myListOfFans.add(fan49);
        batman.myListOfFans.add(fan49);
        supergirl.myListOfFans.add(fan49);
        redSkull.myListOfFans.add(fan49);
        carnage.myListOfFans.add(fan49);
        fanList.add(fan49);

        Fan fan50 = new Fan("Paisley Bennett", "FL-1049");
        theJoker.myListOfFans.add(fan50);
        carnage.myListOfFans.add(fan50);
        supergirl.myListOfFans.add(fan50);
        thor.myListOfFans.add(fan50);
        batman.myListOfFans.add(fan50);
        fanList.add(fan50);


        // Gadgets
        //Assigning weapons to heroes
        characterList.get(0).addGadget(new Weapon("Kryptonite Gun", "GW-1", "Fires kryptonite bullets", 960));
        characterList.get(1).addGadget(new Weapon("Batarang", "GW-2", "Throwable bat-shaped weapon", 850));
        characterList.get(2).addGadget(new Weapon("Web Shooters", "GW-3", "Shoots synthetic webbing", 780));
        characterList.get(3).addGadget(new Weapon("Mjolnir", "GW-4", "Legendary hammer of Thor", 1200));
        characterList.get(4).addGadget(new Weapon("Elastic Suit", "GW-5", "Suit made of unstable molecules", 600));
        characterList.get(5).addGadget(new Weapon("Power Ring", "GW-6", "Harnesses the power of will", 1100));
        characterList.get(6).addGadget(new Weapon("Trick Arrows", "GW-7", "Arrows with various special effects", 720));
        characterList.get(7).addGadget(new Weapon("Lasso of Truth", "GW-8", "Compels truthfulness in those ensnared", 900));
        characterList.get(8).addGadget(new Weapon("Heat Vision", "GW-9", "Fires beams of intense heat from the eyes", 950));
        characterList.get(9).addGadget(new Weapon("Batarang", "GW-10", "Throwable bat-shaped weapon", 850));
        characterList.get(10).addGadget(new Weapon("Photon Blasts", "GW-11", "Energy blasts fueled by cosmic energy", 1000));
        characterList.get(11).addGadget(new Weapon("Trident", "GW-12", "Weapon of the King of Atlantis", 880));
        characterList.get(12).addGadget(new Weapon("Speed Force Gauntlets", "GW-13", "Channels the Speed Force for attacks", 1100));
        characterList.get(13).addGadget(new Weapon("Vibranium Claws", "GW-14", "Claws made of nearly indestructible metal", 1050));
        characterList.get(14).addGadget(new Weapon("Repulsor Gauntlets", "GW-15", "Fires powerful repulsor blasts", 970));
        characterList.get(15).addGadget(new Weapon("Whip", "GW-16", "Flexible weapon used for acrobatics and combat", 780));
        characterList.get(16).addGadget(new Weapon("Adamantium Claws", "GW-17", "Claws bonded with indestructible metal", 1150));
        characterList.get(17).addGadget(new Weapon("Trick Arrows", "GW-18", "Arrows with various special effects", 720));
        characterList.get(18).addGadget(new Weapon("Billy Club", "GW-19", "Multi-purpose weapon used for fighting crime", 830));
        characterList.get(19).addGadget(new Weapon("Vibranium Shield", "GW-20", "Iconic shield wielded by Captain America", 950));

        //Assigning vehicles to heroes
        characterList.get(0).addGadget(new Vehicle("Supermobile", "GV-1", "Personal flying vehicle", 250, 5));
        characterList.get(1).addGadget(new Vehicle("Batmobile", "GV-2", "High-tech crime-fighting vehicle", 1000, 2));
        characterList.get(2).addGadget(new Vehicle("Spider-Mobile", "GV-3", "Spider-Man's customized vehicle", 800, 1));
        characterList.get(3).addGadget(new Vehicle("Chariot of Thor", "GV-4", "Divine chariot pulled by goats", 1100, 1));
        characterList.get(4).addGadget(new Vehicle("Fantasticar", "GV-5", "Flying vehicle for the Fantastic Four", 950, 4));
        characterList.get(5).addGadget(new Vehicle("Green Lantern Ring", "GV-6", "Manifests constructs for flight", 1200, 1));
        characterList.get(6).addGadget(new Vehicle("Arrowplane", "GV-7", "Green Arrow's aerial vehicle", 850, 1));
        characterList.get(7).addGadget(new Vehicle("Invisible Jet", "GV-8", "Wonder Woman's invisible aircraft", 1100, 4));
        characterList.get(8).addGadget(new Vehicle("Supergirl Rocket", "GV-9", "Supergirl's personal rocket", 1050, 1));
        characterList.get(9).addGadget(new Vehicle("Batcycle", "GV-10", "Motorcycle used by Batgirl", 800, 1));
        characterList.get(10).addGadget(new Vehicle("Captain America's Motorcycle", "GV-11", "Custom motorcycle for Captain America", 950, 1));
        characterList.get(11).addGadget(new Vehicle("Photon Cruiser", "GV-12", "Advanced space-faring vessel", 1300, 5));
        characterList.get(12).addGadget(new Vehicle("Aquaman's Sea Charger", "GV-13", "High-speed aquatic vehicle", 1000, 2));
        characterList.get(13).addGadget(new Vehicle("Speedster", "GV-14", "Custom-built speedster for The Flash", 1150, 1));
        characterList.get(14).addGadget(new Vehicle("Panther Jet", "GV-15", "Sleek aircraft used by Black Panther", 1100, 2));
        characterList.get(15).addGadget(new Vehicle("Iron Man Armor", "GV-16", "Various armors with flight capability", 1200, 1));
        characterList.get(16).addGadget(new Vehicle("Catcycle", "GV-17", "Motorcycle used by Catwoman", 850, 1));
        characterList.get(17).addGadget(new Vehicle("Wolverine's Motorcycle", "GV-18", "Custom motorcycle for Wolverine", 900, 1));
        characterList.get(18).addGadget(new Vehicle("Sky-Cycle", "GV-19", "Custom sky-cycle for Hawkeye", 950, 1));
        characterList.get(19).addGadget(new Vehicle("Daredevil's Billy Club", "GV-20", "Double as a grappling hook and billy club", 800, 1));

        //Assigning lairs to heroes
        characterList.get(0).addGadget(new Lair("The Fortress of Solitude", "GL-1", "The private sanctuary of Superman", "the Arctic"));
        characterList.get(1).addGadget(new Lair("Batcave", "GL-2", "Secret headquarters of Batman", "Gotham City"));
        characterList.get(2).addGadget(new Lair("Spider's Lair", "GL-3", "Hidden base of Spider-Man", "New York City"));
        characterList.get(3).addGadget(new Lair("Asgard", "GL-4", "Home realm of Thor", "Asgard"));
        characterList.get(4).addGadget(new Lair("Baxter Building", "GL-5", "Headquarters of the Fantastic Four", "New York City"));
        characterList.get(5).addGadget(new Lair("Oa", "GL-6", "Central power battery of the Green Lantern Corps", "Sector 0"));
        characterList.get(6).addGadget(new Lair("Arrowcave", "GL-7", "Secret base of Green Arrow", "Star City"));
        characterList.get(7).addGadget(new Lair("Themyscira", "GL-8", "Home island of Wonder Woman", "Mediterranean Sea"));
        characterList.get(8).addGadget(new Lair("Fortress of Solitude", "GL-9", "Supergirl's sanctuary", "the Arctic"));
        characterList.get(9).addGadget(new Lair("Batgirl's Hideout", "GL-10", "Secret base of Batgirl", "Gotham City"));
        characterList.get(10).addGadget(new Lair("Avengers Tower", "GL-11", "Headquarters of the Avengers", "New York City"));
        characterList.get(11).addGadget(new Lair("Atlantis", "GL-12", "Underwater kingdom of Aquaman", "the Atlantic Ocean"));
        characterList.get(12).addGadget(new Lair("Flash Museum", "GL-13", "Museum dedicated to The Flash", "Central City"));
        characterList.get(13).addGadget(new Lair("Wakanda", "GL-14", "Home country of Black Panther", "Africa"));
        characterList.get(14).addGadget(new Lair("Stark Tower", "GL-15", "Headquarters of Stark Industries", "New York City"));
        characterList.get(15).addGadget(new Lair("Cat's Lair", "GL-16", "Hideout of Catwoman", "Gotham City"));
        characterList.get(16).addGadget(new Lair("Wolverine's Cabin", "GL-17", "Remote cabin in the wilderness", "Canada"));
        characterList.get(17).addGadget(new Lair("Hawkeye's Apartment", "GL-18", "Apartment hideout of Hawkeye", "New York City"));
        characterList.get(18).addGadget(new Lair("Hell's Kitchen", "GL-19", "Neighborhood of Daredevil", "New York City"));
        characterList.get(19).addGadget(new Lair("Captain Marvel Base", "GL-20", "Base of operations for Captain Marvel", "Unknown Location"));

        // Assigning weapons to villains
        characterList.get(20).addGadget(new Weapon("LexCorp Power Armor", "GW-20", "High-tech suit worn by Lex Luthor", 1100));
        characterList.get(21).addGadget(new Weapon("Joker Venom", "GW-21", "Deadly toxin used by The Joker", 920));
        characterList.get(22).addGadget(new Weapon("Symbiote tendrils", "GW-22", "Living alien symbiote used by Carnage", 1050));
        characterList.get(23).addGadget(new Weapon("Scepter of Loki", "GW-23", "Artifact granting control over minds", 1150));
        characterList.get(24).addGadget(new Weapon("Doom Ray", "GW-24", "Device capable of emitting destructive energy", 1120));
        characterList.get(25).addGadget(new Weapon("Yellow Power Ring", "GW-25", "Ring harnessing the power of fear", 1180));
        characterList.get(26).addGadget(new Weapon("Merlyn's Bow", "GW-26", "Customized bow used by Malcolm Merlyn", 980));
        characterList.get(27).addGadget(new Weapon("Sword of Ares", "GW-27", "Divine weapon wielded by Ares", 1200));
        characterList.get(28).addGadget(new Weapon("Silver Banshee's Wail", "GW-28", "Sonic scream of Siobhan McDougal", 990));
        characterList.get(29).addGadget(new Weapon("Firefly's Flamethrower", "GW-29", "Weapon that shoots streams of fire", 1050));
        characterList.get(30).addGadget(new Weapon("Hydra Laser", "GW-30", "Advanced laser weapon used by Red Skull", 1160));
        characterList.get(31).addGadget(new Weapon("Atlantean Tech Trident", "GW-31", "High-tech trident wielded by Black Manta", 1150));
        characterList.get(32).addGadget(new Weapon("Tachyon Device", "GW-32", "Device that grants super speed", 1180));
        characterList.get(33).addGadget(new Weapon("Kree Blaster", "GW-33", "Standard issue weapon of Kree soldiers", 950));
        characterList.get(34).addGadget(new Weapon("Mandarin's Rings", "GW-34", "Ancient alien rings with various powers", 1250));
        characterList.get(35).addGadget(new Weapon("Black Mask's Blasters", "GW-35", "Custom blasters used by Black Mask", 1020));
        characterList.get(36).addGadget(new Weapon("Adamantium Claws", "GW-36", "Claws bonded with adamantium", 1200));
        characterList.get(37).addGadget(new Weapon("Crossfire Rifle", "GW-37", "Custom rifle used by Crossfire", 980));
        characterList.get(38).addGadget(new Weapon("Kingpin's Cane", "GW-38", "Cane concealing various weapons", 1050));
        characterList.get(39).addGadget(new Weapon("Kree Blaster", "GW-39", "Standard issue weapon of Kree soldiers", 950));

        // Assigning vehicles to villains
        characterList.get(20).addGadget(new Vehicle("LexCorp Hovercraft", "GV-20", "High-speed hovercraft used by Lex Luthor", 1120, 3));
        characterList.get(21).addGadget(new Vehicle("Jokermobile", "GV-21", "Customized car driven by The Joker", 1050, 2));
        characterList.get(22).addGadget(new Vehicle("Symbiote Rider", "GV-22", "Living symbiote vehicle used by Carnage", 1200, 1));
        characterList.get(23).addGadget(new Vehicle("Loki's Chariot", "GV-23", "Magical chariot pulled by mystical creatures", 1180, 2));
        characterList.get(24).addGadget(new Vehicle("Doomsday Chair", "GV-24", "Hoverchair equipped with various weapons", 1150, 1));
        characterList.get(25).addGadget(new Vehicle("Yellow Power Battery", "GV-25", "Source of power for Sinestro Corps", 1240, 1));
        characterList.get(26).addGadget(new Vehicle("Merlyn's Motorcycle", "GV-26", "Customized motorcycle used by Malcolm Merlyn", 980, 1));
        characterList.get(27).addGadget(new Vehicle("War Chariot of Ares", "GV-27", "Divine chariot pulled by mythical beasts", 1250, 2));
        characterList.get(28).addGadget(new Vehicle("Silver Banshee's Wraith", "GV-28", "Supernatural motorcycle of Siobhan McDougal", 1000, 1));
        characterList.get(29).addGadget(new Vehicle("Firefly's Jetpack", "GV-29", "Personal flight device with flamethrower", 1100, 1));
        characterList.get(30).addGadget(new Vehicle("Hydra Aircraft", "GV-30", "Advanced aircraft used by Hydra agents", 1160, 4));
        characterList.get(31).addGadget(new Vehicle("Manta-Sub", "GV-31", "Submarine used by Black Manta", 1180, 5));
        characterList.get(32).addGadget(new Vehicle("Tachyon Hoverboard", "GV-32", "Hoverboard granting super speed", 1220, 1));
        characterList.get(33).addGadget(new Vehicle("Wakandan Fighter Jet", "GV-33", "Advanced jet used by Killmonger", 1150, 1));
        characterList.get(34).addGadget(new Vehicle("Mandarin's Warship", "GV-34", "Advanced warship equipped with weapons", 1300, 10));
        characterList.get(35).addGadget(new Vehicle("Black Mask's Helicopter", "GV-35", "Customized helicopter used by Black Mask", 1050, 3));
        characterList.get(36).addGadget(new Vehicle("Sabretooth's Motorcycle", "GV-36", "Customized motorcycle used by Sabretooth", 1000, 1));
        characterList.get(37).addGadget(new Vehicle("Crossfire's Van", "GV-37", "Customized van used by Crossfire", 980, 3));
        characterList.get(38).addGadget(new Vehicle("Kingpin's Limousine", "GV-38", "Armored limousine used by Kingpin", 1100, 4));
        characterList.get(39).addGadget(new Vehicle("Kree Warship", "GV-39", "Advanced spacecraft used by Kree Empire", 1200, 10));

        // Assigning lairs to villains
        characterList.get(20).addGadget(new Lair("LexCorp Tower", "GL-20", "Corporate headquarters of Lex Luthor", "Metropolis"));
        characterList.get(21).addGadget(new Lair("Ace Chemicals Plant", "GL-21", "Chemical factory turned hideout of The Joker", "Gotham City"));
        characterList.get(22).addGadget(new Lair("Carnage's Hideout", "GL-22", "Secret base of Carnage", "New York City"));
        characterList.get(23).addGadget(new Lair("Asgardian Hideout", "GL-23", "Secret refuge of Loki", "Asgard"));
        characterList.get(24).addGadget(new Lair("Doomstadt Castle", "GL-24", "Fortress of Doctor Doom", "Latveria"));
        characterList.get(25).addGadget(new Lair("Qward", "GL-25", "Home base of Sinestro Corps", "Anti-Matter Universe"));
        characterList.get(26).addGadget(new Lair("Star City Warehouse", "GL-26", "Hideout of Malcolm Merlyn", "Star City"));
        characterList.get(27).addGadget(new Lair("Temple of Ares", "GL-27", "Ancient temple used by Ares", "Greece"));
        characterList.get(28).addGadget(new Lair("Silver Banshee's Crypt", "GL-28", "Crypt used by Siobhan McDougal", "Unknown Location"));
        characterList.get(29).addGadget(new Lair("Firefly's Warehouse", "GL-29", "Secret warehouse hideout of Firefly", "Gotham City"));
        characterList.get(30).addGadget(new Lair("Hydra Base", "GL-30", "Secret base of Hydra", "Unknown Location"));
        characterList.get(31).addGadget(new Lair("Manta Lair", "GL-31", "Underwater lair of Black Manta", "Unknown Location"));
        characterList.get(32).addGadget(new Lair("Time Vault", "GL-32", "Temporal hideout of The Reverse Flash", "Unknown Location"));
        characterList.get(33).addGadget(new Lair("Wakandan Outpost", "GL-33", "Remote outpost in Wakanda", "Wakanda"));
        characterList.get(34).addGadget(new Lair("Valley of Spirits", "GL-34", "Base hidden in the mountains by The Mandarin", "China"));
        characterList.get(35).addGadget(new Lair("Black Mask's Mansion", "GL-35", "Luxurious mansion used as a hideout", "Gotham City"));
        characterList.get(36).addGadget(new Lair("Sabretooth's Cave", "GL-36", "Remote cave hideout of Sabretooth", "Canada"));
        characterList.get(37).addGadget(new Lair("Crossfire's Safehouse", "GL-37", "Hideout used by Crossfire and his gang", "Unknown Location"));
        characterList.get(38).addGadget(new Lair("Fisk Tower", "GL-38", "Skyscraper owned by Kingpin", "New York City"));
        characterList.get(39).addGadget(new Lair("Kree Outpost", "GL-39", "Remote outpost controlled by Yon-Rogg", "Unknown Location"));

        // Teams
        HeroTeam theJusticeLeague = new HeroTeam("The Justice League", "HT-1");
        theJusticeLeague.addHero(superman);
        theJusticeLeague.addHero(wonderWoman);
        theJusticeLeague.addHero(theFlash);
        theJusticeLeague.addHero(greenLantern);
        theJusticeLeague.addHero(aquaman);
        teamList.add(theJusticeLeague);

        HeroTeam theAvengers = new HeroTeam("The Avengers", "HT-2");
        theAvengers.addHero(thor);
        theAvengers.addHero(captainAmerica);
        theAvengers.addHero(ironMan);
        theAvengers.addHero(blackPanther);
        theAvengers.addHero(wolverine);
        teamList.add(theAvengers);

        HeroTeam theGuardianAlliance = new HeroTeam("The Guardian Alliance", "HT-3");
        theGuardianAlliance.addHero(batman);
        theGuardianAlliance.addHero(greenArrow);
        theGuardianAlliance.addHero(batgirl);
        theGuardianAlliance.addHero(hawkeye);
        theGuardianAlliance.addHero(daredevil);
        teamList.add(theGuardianAlliance);

        HeroTeam theFantasticFour = new HeroTeam("The Fantastic Four", "HT-4");
        theFantasticFour.addHero(mrFantastic);
        theFantasticFour.addHero(spiderMan);
        theFantasticFour.addHero(supergirl);
        theFantasticFour.addHero(catwoman);
        teamList.add(theFantasticFour);

        VillainTeam theSinisterSyndicate = new VillainTeam("The Sinister Syndicate", "VT-1");
        theSinisterSyndicate.addVillain(carnage);
        theSinisterSyndicate.addVillain(doctorDoom);
        theSinisterSyndicate.addVillain(sabretooth);
        teamList.add(theSinisterSyndicate);

        VillainTeam theMalevolentMasters = new VillainTeam("The Malevolent Masters", "VT-2");
        theMalevolentMasters.addVillain(lexLuthor);
        theMalevolentMasters.addVillain(loki);
        theMalevolentMasters.addVillain(blackManta);
        theMalevolentMasters.addVillain(theMandarin);
        teamList.add(theMalevolentMasters);

        VillainTeam theViciousVanguard = new VillainTeam("The Vicious Vanguard", "VT-3");
        theViciousVanguard.addVillain(theJoker);
        theViciousVanguard.addVillain(sinestro);
        theViciousVanguard.addVillain(firefly);
        theViciousVanguard.addVillain(redSkull);
        teamList.add(theViciousVanguard);

        VillainTeam theRuthlessRenegades = new VillainTeam("The Ruthless Renegades", "VT-4");
        theRuthlessRenegades.addVillain(ares);
        theRuthlessRenegades.addVillain(killmonger);
        theRuthlessRenegades.addVillain(kingpin);
        teamList.add(theRuthlessRenegades);

        boolean go = false;
        // Display Main Menu
        while (!go) {
            Menu.displayMainMenu();
            int choice = Menu.getMainMenuChoice();
            switch (choice) {
                //Display People & Teams Menu
                case 1:
                    Menu.displayPeopleAndTeamsMenu();
                    int choice1 = Menu.getPeopleAndTeamsMenuChoice();
                    switch (choice1) {
                        case 1:
                            Hero.displayAllHeroes(characterList);//display all heroes;
                            String selectHeroID = Menu.getHeroIdFromUserInput(); //input to get full information of hero
                            Hero.displayOneHeroFullInformation(characterList, selectHeroID); //input for arraylist to get id input
                            int input = Menu.getMenuOrQuitOption();//choice break or start while loop again.
                            if (input == 2) {
                                go = true;
                                break;
                            }
                            break;
                        case 2:
                            Villain.displayAllVillains(characterList);//display all villains
                            String VillainID = Menu.getVillainIdFromUserInput();//input to get full information of villain
                            Villain.displayOneVillainFullInformation(characterList, VillainID); //input verwerken in arraylist to get full information
                            input = Menu.getMenuOrQuitOption();//choice break or start while loop again.
                            if (input == 2) {
                                go = true;
                                break;
                            }
                            break;
                        case 3:
                            Menu.displayFans(fanList);
                            input = Menu.getMenuOrQuitOption();
                            if (input == 2) {
                                go = true;
                                break;
                            }
                            break;
                        case 4:
                            for (Team team : teamList) {
                                System.out.println(team.getAsString());
                            }
                            input = Menu.getMenuOrQuitOption();
                            if (input == 2) {
                                go = true;
                                break;
                            }
                            break;
                        case 5:
                            for (Team team : teamList) {
                                System.out.println(team.getAsString());
                            }
                            Hero.displayAllHeroes(characterList);
                            Villain.displayAllVillains(characterList);
                            Team.displayAllVillainTeams(teamList);
                            Team.displayAllHeroTeams(teamList);
                            String IdHeroOrVillain = Menu.GetHeroOrVillainIdFromUserInput();
                            ComicCharacter.displayOneHeroOrVillainFullInformation(characterList, IdHeroOrVillain);
                            input = Menu.getMenuOrQuitOption();
                            if (input == 2) {
                                go = true;
                                break;
                            }
                            break;
                        case 0:
                            // Code to exit the menu
                            System.out.println("Exiting People & Teams Menu...");
                            break;
                        default:
                            try {
                                System.out.println("Invalid choice. Please try again.");
                            } catch (NumberFormatException | InputMismatchException e) {
                                System.out.println("Invalid input. Please try again.");
                            }
                    }
                    break;

                //Display Gadgets Menu
                case 2:
                    System.out.println("");
                    System.out.println("");
                    Menu.displayMenuOfGadgets(); // Display gadgets menu
                    int choice2 = Menu.displayGadgetsMenu();
                    switch (choice2) {
                        case 1:
                            Menu.viewAllGadgets(characterList);
                            break;
                        case 2:
                            Menu.searchInGadgets(characterList);
                            break;
                        case 0:
                            System.out.println("Exiting Gadgets Menu...");
                            break;
                        default:
                            try {
                                System.out.println("Invalid choice. Please try again.");
                            } catch (NumberFormatException | InputMismatchException e) {
                                System.out.println("Invalid input. Please try again.");
                            }
                            break;
                    }
                    int choiceExitMenu = Menu.getMenuOrQuitOption();
                    if (choiceExitMenu == 1) {
                        System.out.println("Exiting to the Main Menu...");
                    } else if (choiceExitMenu == 2) {
                        System.out.println("Exiting the game...");
                        go = true;
                    } else {
                        System.out.println("Invalid choice. Please try again.");
                    }
                    break;

                //Display Fights Menu
                case 3:
                    Menu.displayMenuFights();
                    int choice3 = Menu.getMainMenuChoice();
                    switch (choice3) {
                        case 1:
                            Menu.displayAllIndividualFights();
                            break;
                        case 2:
                            Menu.displayAllTeamFights();
                            break;
                        case 3:
                            IndividualFight.selectCharactersForFight(characterList, scanner);
                            break;
                        case 4:
                            TeamFight.selectTeamsForFight(teamList, scanner);
                            break;
                        case 5:
                            IndividualFight.searchIndividualFight(scanner);
                            break;
                        case 6:
                            TeamFight.searchTeamFight(scanner);
                            break;
                        case 0:
                            System.out.println("Exiting Fights Menu...");
                            break;
                        default:
                            try {
                                System.out.println("Invalid choice. Please try again.");
                            } catch (NumberFormatException | InputMismatchException e) {
                                System.out.println("Invalid input. Please try again.");
                            }
                            break;
                    }
                    choiceExitMenu = Menu.getMenuOrQuitOption();
                    if (choiceExitMenu == 1) {
                        System.out.println("Exiting to the Main Menu...");
                    } else if (choiceExitMenu == 2) {
                        System.out.println("Exiting the game...");
                        go = true;
                    } else {
                        System.out.println("Invalid choice. Please try again.");
                    }
                    break;

                //Exit the loop
                case 0:
                    System.out.println("Exiting the game.");
                    go = true;
                    break;
                default:
                    try {
                        System.out.println("Invalid choice. Please try again.");
                    } catch (NumberFormatException | InputMismatchException e) {
                        System.out.println("Invalid input. Please try again.");
                    }
                    break;
            }
        }
    }
}