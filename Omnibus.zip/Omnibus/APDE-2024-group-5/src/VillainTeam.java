public class VillainTeam extends Team {

    public VillainTeam(String name, String id) {
        super(name, id);
    }

    public void addVillain(Villain villain) {
        addMember(villain);
    }

}
