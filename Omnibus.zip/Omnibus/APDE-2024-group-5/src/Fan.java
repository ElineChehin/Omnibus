public class Fan extends Entity {

    public Fan(String name, String id) {
        super(name, id);
    }
}




