import java.util.ArrayList;
import java.util.List;

public abstract class ComicCharacter extends Entity {
    protected String location;
    protected String oneLiner = "Haha! Here I come!";
    protected String antiFriendBook;
    protected int powerLevel;
    protected String archEnemy;

    public ArrayList<Gadget> myListOfGadgets = new ArrayList<>();
    public ArrayList<Entity> myListOfFans = new ArrayList<>();
    private static ArrayList<ComicCharacter> characters = new ArrayList<>();

    public ComicCharacter(String name, String id, String location, String oneLiner, String antiFriendBook, int powerLevel, String archEnemy) {
        super(name, id);
        this.location = location;
        this.oneLiner = oneLiner;
        this.antiFriendBook = antiFriendBook;
        this.powerLevel = powerLevel;
        this.archEnemy = archEnemy;
        characters.add(this);
    }

    public String getLocation() {
        return location;
    }

    public String getOneLiner() {
        return oneLiner;
    }

    public String getAntiFriendBook() {
        return antiFriendBook;
    }

    public int getPowerLevel() {
        return powerLevel;
    }

    public String getArchEnemy() {
        return archEnemy;
    }

    public void setArchEnemy(String archEnemy) {
        this.archEnemy = archEnemy;
    }

    public void addGadget(Gadget newGadget) {
        myListOfGadgets.add(newGadget);
    }

    public void displayAllFans() {
        System.out.println("Fans:");
        for (Entity fan : myListOfFans) {
            System.out.println("- " + fan.getName());
        }
    }
    public void clearAllFans() {
        myListOfFans.clear();
    }


    public static int calculateArchEnemyBonus(ComicCharacter character, ComicCharacter archEnemy) {
        int archEnemyBonus = 0;
        if (archEnemy != null && character.getArchEnemy() != null && character.getArchEnemy().equals(archEnemy.getName())) {
            archEnemyBonus += 1000;
        }
        return archEnemyBonus;
    }

    public static void displayOneHeroOrVillainFullInformation(List<ComicCharacter> characters, String Input) {
        boolean found = false;
        for (ComicCharacter character : characters) {
            if (character instanceof Villain && character.getId().equalsIgnoreCase(Input)) {
                found = true;
                System.out.println();
                System.out.println("Information of Hero\n");
                System.out.println("Name: " + character.getName());
                System.out.println("ID: " + character.getId());
                System.out.println("Evil Plan: " + ((Villain) character).getEvilPlan());
                System.out.println("Location: " + character.getLocation());
                System.out.println("One-liner: " + character.getOneLiner());
                System.out.println("Anti-friend Book: " + character.getAntiFriendBook());
                System.out.println("Power Level: " + character.getPowerLevel());
                character.displayAllFans();
                System.out.println();
            } else if (character instanceof Hero && character.getId().equalsIgnoreCase(Input)) {
                found = true;
                System.out.println();
                System.out.println("Full information of " + character.getName() + ":");
                System.out.println("Name: " + character.getName());
                System.out.println("ID: " + character.getId());
                System.out.println("Location: " + character.getLocation());
                System.out.println("One-liner: " + character.getOneLiner());
                System.out.println("Anti-friend Book: " + character.getAntiFriendBook());
                System.out.println("Power Level: " + character.getPowerLevel());
                System.out.println("Real name: " + ((Hero) character).getRealName() + "\n");
                character.displayAllFans();
                System.out.println();
            }
        }
        if (!found) {
            System.out.println("Villain with ID " + Input + " not found.\n");
        }
    }
}
