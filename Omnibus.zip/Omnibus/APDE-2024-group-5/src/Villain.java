import java.util.ArrayList;
import java.util.List;

public class Villain extends ComicCharacter {
    private String evilPlan;
    private ArrayList<Fan> fans = new ArrayList<>();

    public Villain(String name, String id, String location, String oneLiner, String antiFriendBook, int powerLevel, String archEnemy, String evilPlan) {
        super(name, id, location, oneLiner, antiFriendBook, powerLevel, archEnemy);
        this.evilPlan = evilPlan;
    }

    public String getEvilPlan() {
        return evilPlan;
    }
    public int getNumFans() {
        return fans.size();
    }

    public static void displayAllVillains(List<ComicCharacter> characters) {
        System.out.println("List and information of all villains");
        for (int i = 0; i < characters.size(); i++) {
            ComicCharacter character = characters.get(i);
            if (character instanceof Villain) {
                System.out.println("Name: " + character.getName());
                System.out.println("ID: " + character.getId());
                System.out.println();
            }
        }
    }
    public static void displayOneVillainFullInformation(List<ComicCharacter> characters, String VillainId) {
        boolean found = false;
        System.out.println();
        System.out.println("Information of all villains:");
        for (int i = 0; i < characters.size(); i++) {
            ComicCharacter character = characters.get(i);
            if (character instanceof Villain && character.getId().equalsIgnoreCase(VillainId)) {
                System.out.println("Name: " + character.getName());
                System.out.println("ID: " + character.getId());
                System.out.println("Evil Plan: " + ((Villain) character).getEvilPlan());
                System.out.println("Location: " + character.getLocation());
                System.out.println("One-liner: " + character.getOneLiner());
                System.out.println("Anti-friend Book: " + character.getAntiFriendBook());
                System.out.println("Power Level: " + character.getPowerLevel());
                System.out.println();
                character.displayAllFans();
                System.out.println();
            }
        }
        if (!found) {
            System.out.println("Villain with ID " + VillainId + " not found.\n");
        }
    }
}
