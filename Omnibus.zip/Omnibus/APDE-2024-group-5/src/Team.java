import java.util.ArrayList;
import java.util.List;
public abstract class Team {
    private ArrayList<ComicCharacter> memberList;
    protected String name;
    protected String id;

    public Team(String name, String id) {
        this.name = name;
        this.id = id;
        this.memberList = new ArrayList<>();
    }

    public void addMember(ComicCharacter member) {
        this.memberList.add(member);
    }

    public String getName() {
        return name;
    }

    public String getID() {
        return id;
    }

    public static int calculateTeamPower(Team team, Team enemyTeam) {
        int totalPower = 0;
        List<ComicCharacter> members = team.getMembers();
        for (ComicCharacter member : members) {
            totalPower += member.getPowerLevel();
            ComicCharacter archEnemy = findArchEnemy(member, enemyTeam);
            totalPower += ComicCharacter.calculateArchEnemyBonus(member, archEnemy);
            totalPower += member.getNumFans() * 2;
        }
        return totalPower;
    }
    public static ComicCharacter findArchEnemy(ComicCharacter character, Team enemyTeam) {
        List<ComicCharacter> enemyMembers = enemyTeam.getMembers();
        for (int i = 0; i < enemyMembers.size(); i++) {
            ComicCharacter enemy = enemyMembers.get(i);
            if (enemy.getName().equals(character.getArchEnemy())) {
                return enemy;//found
            }
        }
        return null; // Found no archenemy
    }

    public String getAsString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder
                .append(getID())
                .append("  -  ")
                .append(getName())
                .append("\n");
        for (ComicCharacter member : this.memberList) {
            stringBuilder.append(member.getName()).append("\n");
        }
        return stringBuilder.toString();
    }

    public List<ComicCharacter> getMembers() {
        return memberList;
    }

    public static void displayAllHeroTeams(List<Team> teams) {
        for (Team team : teams) {
            if (team instanceof HeroTeam) {
                System.out.println("Name: " + team.getName());
                System.out.println("ID: " + team.getID());
                System.out.println();
            }
        }
    }

    public static void displayAllVillainTeams(List<Team> teams) {
        for (Team team : teams) {
            if (team instanceof VillainTeam) {
                System.out.println("Name: " + team.getName());
                System.out.println("ID: " + team.getID());
                System.out.println();
            }
        }
    }
}

