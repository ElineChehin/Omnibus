import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Menu {
    private static Scanner scanner = new Scanner(System.in);

    //Method: Main Menu
    public static void displayMainMenu() {
        System.out.println("Welcome to Omnibus!");
        System.out.println("(1) Menu People & Teams");
        System.out.println("(2) Menu Gadgets");
        System.out.println("(3) Menu Fights");
        System.out.println("(0) Exit the game");
    }

    //Method: People & Teams Menu
    public static void displayPeopleAndTeamsMenu() {
        System.out.println("Please select from the People & Teams menu");
        System.out.println("(1) View all Heroes");
        System.out.println("(2) View all Villains");
        System.out.println("(3) View all Fans");
        System.out.println("(4) View all Teams");
        System.out.println("(5) Search for Hero & Teams");
        System.out.println("(0) Exit game");
    }

    public static void displayFans(List<Entity> fans) {
        for (int i = 0; i < fans.size(); i++) {
            Entity fan = fans.get(i);
            if (fan instanceof Fan) {
                System.out.println("Name: " + fan.getName());
                System.out.println("ID: " + fan.getId());
            }
        }
    }

    //Method: Gadgets Menu
    public static int displayGadgetsMenu() {
        while (true) {
            try {
                System.out.println("Please select from the Gadgets menu!");
                System.out.println("(1) View a list of all Gadgets.");
                System.out.println("(2) Search in Gadgets (To search please insert a name or ID)");
                System.out.println("(0) Exit the Gadgets Menu.");
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please try again");
                scanner.nextLine();
            }
        }
    }

    // Method: to view all gadgets
    public static void viewAllGadgets(ArrayList<ComicCharacter> characters) {
        System.out.println("List of all Gadgets for each character:");
        for (ComicCharacter character : characters) {
            for (Gadget gadget : character.myListOfGadgets) {
                gadget.attributes();
                System.out.println();
            }
            System.out.println();
        }
    }
    public static void displayMenuOfGadgets() {
    }


    // Method to search in gadgets
    public static void searchInGadgets(ArrayList<ComicCharacter> characters) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the name or ID of the gadget to search: ");
        String searchKeyword = scanner.nextLine().trim();

        boolean found = false;
        for (ComicCharacter character : characters) {
            for (Gadget gadget : character.myListOfGadgets) {
                if (gadget.getName().equalsIgnoreCase(searchKeyword) || gadget.getID().equalsIgnoreCase(searchKeyword)) {
                    System.out.println("Gadget found:");
                    gadget.attributes();
                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("Gadget with name or ID '" + searchKeyword + "' not found.");
        }
    }

    //Method: Fights Menu
    public static int displayMenuFights() {
        System.out.println("Fight Menu");
        System.out.println("(1) View a list of all 1 vs 1 fights");
        System.out.println("(2) View a list of all team fights");
        System.out.println("(3) Start a 1 vs 1 fight");
        System.out.println("(4) Start a team fight");
        System.out.println("(5) Search a 1 vs 1 fight");
        System.out.println("(6) Search a team fight");
        System.out.println("(0) Exit game.");
        return 0;
    }

    public static void displayAllIndividualFights() {
        System.out.println("List of all individual fights:");
        for (IndividualFight fight : IndividualFight.singleFightList) {
            System.out.println("The hero \"" + fight.getHero().getName() + "\" vs " + "villain \"" + fight.getVillain().getName() + "\" fight outcome is:");
            System.out.println("The winner is: " + fight.getWinner().getName());
            System.out.println("The loser is: " + fight.getLoser().getName());
            System.out.println();
        }
    }

    public static void displayAllTeamFights() {
        System.out.println("List of all team fights:");
        for (int i = 0; i < TeamFight.teamFightList.size(); i++) {
            TeamFight fight = TeamFight.teamFightList.get(i);
            System.out.println("Winning Team: " + fight.getWinningTeam().getName());
            System.out.println("Hero Team: " + fight.getHeroTeam().getName());
            System.out.println("Villain Team: " + fight.getVillainTeam().getName());
            System.out.println();
        }
    }

    //Method: get choice of input in main
    public static int getMainMenuChoice() {
        while (true) {
            try {
                System.out.print("Make a choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();
                System.out.println(" ");
                return choice;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please try again");
                scanner.nextLine();
            }
        }
    }

    //Method: get People & Teams Menu
    public static int getPeopleAndTeamsMenuChoice() {
        while (true) {
            try {
                System.out.print("Please select from the People & Teams Menu: ");
                int choice = scanner.nextInt();
                scanner.nextLine();
                System.out.println(" ");
                return choice;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please try again");
                scanner.nextLine();
            }
        }
    }

    //Method: get user input for Villain ID
    public static String getVillainIdFromUserInput() {
        System.out.println("Enter the ID of the villain to view full information:");
        String input = scanner.nextLine();
        return input;
    }

    //Method: get user input for Hero ID
    public static String getHeroIdFromUserInput() {
        System.out.println("Enter the ID of the hero to view full information:");
        String input = scanner.nextLine();
        return input;
    }

    //Menu to view full information of a Hero or Villain
    public static String GetHeroOrVillainIdFromUserInput() {
        System.out.println("Enter the ID of the hero or villain to view full information:");
        String input = scanner.nextLine();
        return input;
    }

    public static void displayFightOptions(ComicCharacter selectedHero, ComicCharacter selectedVillain, Scanner scanner) {
        Integer choiceFight;
        boolean correctInput = false;

        while (!correctInput) {
            System.out.println("Do you want to pick a winner or let them fight?");
            System.out.println(" ");
            System.out.println("Press 1: Let them fight");
            System.out.println("Press 2: " + selectedHero.getName() + " wins");
            System.out.println("Press 3: " + selectedVillain.getName() + " wins");

            choiceFight = Integer.valueOf(scanner.nextLine());
            if (choiceFight == 1) {
                IndividualFight newFight = new IndividualFight(selectedHero, selectedVillain);
                newFight.startFight();
                correctInput = true;
            } else if (choiceFight == 2) {
                IndividualFight.addWinner(selectedHero, selectedVillain, selectedHero, selectedVillain);
                System.out.println("The winner is " + selectedHero.getName() + ".\n");
                correctInput = true;
            } else if (choiceFight == 3) {
                System.out.println("The winner is " + selectedVillain.getName() + ".\n");
                correctInput = true;
            }
        }
    }


    //Menu: To return to the Main or Quit the game
    public static int getMenuOrQuitOption() {
        while (true) {
            try {
                System.out.println("Back to menu, press 1. To quit, press 2.");
                int input = scanner.nextInt();
                if (input == 1) {
                    System.out.println("Back to menu.\n");
                } else if (input == 2) {
                    System.out.println("GAME OVER!");
                } else {
                    System.out.println("Input not valid, back to menu." + "\n");
                }
                return input;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please try again.");
                scanner.nextLine(); // Clear the invalid input
            }
        }
    }

}
