class Vehicle extends Gadget {
    private int topSpeed;
    private int maxCapacity;

    public Vehicle(String name, String ID, String description, int topSpeed, int maxCapacity) {
        super(name, ID, description);
        this.topSpeed = topSpeed;
        this.maxCapacity = maxCapacity;
    }

    @Override
    public void attributes() {
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Description: " + getDescription());
        System.out.println("Top speed: " + topSpeed);
        System.out.println("Maximum capacity: " + maxCapacity);
    }
}
