import java.util.ArrayList;
import java.util.List;

public class Hero extends ComicCharacter {
    private String realName;
    private ArrayList<Fan> fans = new ArrayList<>();

    public Hero(String name, String id, String location, String oneLiner, String antiFriendBook, int powerLevel, String realName, String archEnemy) {
        super(name, id, location, oneLiner, antiFriendBook, powerLevel, archEnemy);
        this.realName = realName;

    }

    public String getRealName() {
        return realName;
    }

    public int getNumFans() {
        return fans.size();
    }

    public static void displayAllHeroes(List<ComicCharacter> characters) {
        System.out.println("List and information of all heroes:");
        for (ComicCharacter character : characters) {
            if (character instanceof Hero) {
                System.out.println("Name: " + character.getName());
                System.out.println("ID: " + character.getId());
                System.out.println("Location: " + character.getLocation());
                System.out.println("One-liner: " + character.getOneLiner());
                System.out.println("Anti-friend Book: " + character.getAntiFriendBook());
                System.out.println("Power Level: " + character.getPowerLevel());
                System.out.println("Real name: " + ((Hero) character).getRealName() + "\n");
                character.displayAllFans();
                System.out.println();
            }
        }
    }
    public static void displayOneHeroFullInformation(List<ComicCharacter> characters, String heroID) {
        boolean found = false;
        for (int i = 0; i < characters.size(); i++) {
            ComicCharacter character = characters.get(i);
            if (character instanceof Hero && character.getId().equalsIgnoreCase(heroID)) {
                System.out.println();
                System.out.println("Full information of " + character.getName() + ":");
                System.out.println("Name: " + character.getName());
                System.out.println("ID: " + character.getId());
                System.out.println("Location: " + character.getLocation());
                System.out.println("One-liner: " + character.getOneLiner());
                System.out.println("Anti-friend Book: " + character.getAntiFriendBook());
                System.out.println("Power Level: " + character.getPowerLevel());
                System.out.println("Real name: " + ((Hero) character).getRealName() + "\n");
                character.displayAllFans();
                System.out.println();
                return;
            }
        }
        if (!found) {
            System.out.println("Hero with ID " + heroID + " not found.\n");
        }
    }
}



