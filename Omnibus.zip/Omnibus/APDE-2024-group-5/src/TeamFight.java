import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TeamFight extends Fight {

    private Team winningTeam;
    private VillainTeam villainTeam;
    private HeroTeam heroTeam;
    public static List<TeamFight> teamFightList = new ArrayList<>();

    public TeamFight(HeroTeam heroTeam, VillainTeam villainTeam) {
        super();
        this.heroTeam = heroTeam;
        this.villainTeam = villainTeam;
    }

    public Team getWinningTeam() {
        return winningTeam;
    }

    public VillainTeam getVillainTeam() {
        return villainTeam;
    }

    public HeroTeam getHeroTeam() {
        return heroTeam;
    }

    public static void printTeamFightIntroduction(HeroTeam heroTeam, VillainTeam villainTeam) {
        System.out.println(heroTeam.getName() + " vs " + villainTeam.getName());
        System.out.println("The fight begins!\n");
    }

    public static void simulateTeamFight(HeroTeam heroTeam, VillainTeam villainTeam) {
        printTeamFightIntroduction(heroTeam, villainTeam);

        int heroTeamPower = calculateTeamPowerWithBonus(heroTeam, villainTeam);
        int villainTeamPower = calculateTeamPowerWithBonus(villainTeam, heroTeam);

        while (heroTeamPower > 0 && villainTeamPower > 0) {
            heroTeamPower = processHeroTeamAttack(heroTeam, villainTeam, heroTeamPower, villainTeamPower);
            villainTeamPower = processVillainTeamAttack(heroTeam, villainTeam, heroTeamPower, villainTeamPower);
            displayTeamHealth(heroTeam, villainTeam, heroTeamPower, villainTeamPower);
        }

        TeamFight newTeamFight = addTeamFightToList(heroTeam, villainTeam);
        decideWinnerTeam(heroTeam, villainTeam, heroTeamPower, villainTeamPower, newTeamFight);
    }

    private static int calculateTeamPowerWithBonus(Team team, Team opponent) {
        return Team.calculateTeamPower(team, opponent) + Gadget.getGadgetsBonus();
    }

    private static int processHeroTeamAttack(HeroTeam heroTeam, VillainTeam villainTeam, int heroTeamPower, int villainTeamPower) {
        int heroTeamAttack = (int) (Math.random() * 500);
        villainTeamPower -= heroTeamAttack;
        System.out.println(heroTeam.getName() + " hits " + villainTeam.getName() + " for " + heroTeamAttack + " damage.");
        return villainTeamPower;
    }

    private static int processVillainTeamAttack(HeroTeam heroTeam, VillainTeam villainTeam, int heroTeamPower, int villainTeamPower) {
        int villainAttack = (int) (Math.random() * 500);
        heroTeamPower -= villainAttack;
        System.out.println(villainTeam.getName() + " hits " + heroTeam.getName() + " for " + villainAttack + " damage.");
        return heroTeamPower;
    }

    private static void displayTeamHealth(HeroTeam heroTeam, VillainTeam villainTeam, int heroTeamPower, int villainTeamPower) {
        System.out.println(heroTeam.getName() + " Health: " + heroTeamPower);
        System.out.println(villainTeam.getName() + " Health: " + villainTeamPower + "\n");
    }

    private static TeamFight addTeamFightToList(HeroTeam heroTeam, VillainTeam villainTeam) {
        TeamFight newTeamFight = new TeamFight(heroTeam, villainTeam);
        teamFightList.add(newTeamFight);
        return newTeamFight;
    }

    private static void decideWinnerTeam(HeroTeam heroTeam, VillainTeam villainTeam, int heroTeamPower, int villainTeamPower, TeamFight newTeamFight) {
        if (heroTeamPower <= 0) {
            System.out.println(villainTeam.getName() + " wins the fight!");
            newTeamFight.winningTeam = villainTeam;
        } else {
            System.out.println(heroTeam.getName() + " wins the fight!");
            newTeamFight.winningTeam = heroTeam;
        }
    }

    public static void searchTeamFight(Scanner scanner) {
        System.out.println("Which teams participated in the fight?");

        String name = scanner.nextLine();
        for (TeamFight teamFight : teamFightList) {
            if (teamFight.getVillainTeam().getName().equalsIgnoreCase(name) ||
                    teamFight.getHeroTeam().getName().equalsIgnoreCase(name)) {
                System.out.println(teamFight.getDetails());
                System.out.println("------------------------");
            }
        }
    }
    public String getDetails() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hero team: ").append(getHeroTeam().getName()).append("\n");
        stringBuilder.append("Villain team: ").append(getVillainTeam().getName()).append("\n");
        if (getWinningTeam() == null) {
            stringBuilder.append("This fight hasn't started yet\n");
        } else {
            stringBuilder.append(getWinningTeam().getName()).append(" won the fight!\n");
        }
        return stringBuilder.toString();
    }

    // Team fight
    public static void selectTeamsForFight(List<Team> teams, Scanner scanner) {
        Team selectedHeroTeam = null;
        Team selectedVillainTeam = null;
        boolean correctInput = false;
        String selectedHeroTeamID = null;
        String selectedVillainTeamID = null;

        while (!correctInput) {
            System.out.println("Hero Teams: ");
            Team.displayAllHeroTeams(teams);

            System.out.println("Enter the ID of the Team of Heroes you want to fight with from the list above:");
            selectedHeroTeamID = scanner.nextLine().toUpperCase();

            for (Team heroTeam : teams) {
                if (heroTeam.getID().equals(selectedHeroTeamID) && heroTeam instanceof HeroTeam) {
                    selectedHeroTeam = heroTeam;
                    correctInput = true;
                    break;
                }
            }

            if (!correctInput) {
                System.out.println("Error: team not found or wrong ID.");
            } else {
                System.out.println("You have selected: " + selectedHeroTeam.getName());
            }
        }

        correctInput = false;

        System.out.println("Select a Team of Villains for the fight:\n");
        Team.displayAllVillainTeams(teams);

        while (!correctInput) {
            System.out.println("Villain Teams: ");
            Team.displayAllVillainTeams(teams);

            System.out.println("Enter the ID of the Team of Villains you want to fight against from the list above: ");
            selectedVillainTeamID = scanner.nextLine().toUpperCase();

            for (Team villainTeam : teams) {
                if (villainTeam.getID().equals(selectedVillainTeamID) && villainTeam instanceof VillainTeam) {
                    selectedVillainTeam = villainTeam;
                    correctInput = true;
                    break;
                }
            }

            if (!correctInput) {
                System.out.println("Error: team not found or wrong ID.");
            } else {
                System.out.println("You have selected: " + selectedVillainTeam.getName());
            }
        }

        System.out.println("You have selected: ");
        System.out.println("Hero Team: " + selectedHeroTeam.getName());
        System.out.println("Villain Team: " + selectedVillainTeam.getName());

        // Start Team fight
        TeamFight.simulateTeamFight((HeroTeam) selectedHeroTeam, (VillainTeam) selectedVillainTeam);
    }
}
