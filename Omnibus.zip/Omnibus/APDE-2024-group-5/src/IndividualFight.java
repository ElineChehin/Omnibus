import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class IndividualFight extends Fight {

    private ComicCharacter winner;
    private ComicCharacter loser;
    private ComicCharacter hero;
    private ComicCharacter villain;
    public static ArrayList<IndividualFight> singleFightList = new ArrayList<>();

    public IndividualFight(ComicCharacter hero, ComicCharacter villain) {
        super();
        this.hero = hero;
        this.villain = villain;
    }

    public static void addWinner(ComicCharacter winner, ComicCharacter loser, ComicCharacter hero, ComicCharacter villain) {
        IndividualFight newFight = new IndividualFight(hero, villain);
        newFight.winner = winner;
        newFight.loser = loser;
        singleFightList.add(newFight);
    }

    public static void transferFansAfterFight(ComicCharacter winner, ComicCharacter loser) {
        winner.myListOfFans.addAll(loser.myListOfFans);
        loser.myListOfFans.clear();
    }

    public static void printFightIntroduction(ComicCharacter hero, ComicCharacter villain) {
        System.out.println(hero.getName() + " vs " + villain.getName());
        System.out.println("Fight begins!\n");
        System.out.println(hero.getName() + ": " + hero.getOneLiner());
        System.out.println(villain.getName() + ": " + villain.getOneLiner());
    }

    public void startFight() {
        printFightIntroduction(hero, villain);

        int heroHealth = hero.getPowerLevel() + Gadget.getGadgetsBonus();
        int villainHealth = villain.getPowerLevel() + Gadget.getGadgetsBonus();

        while (heroHealth > 0 && villainHealth > 0) {
            heroHealth = attack(hero, villain, heroHealth, true);
            villainHealth = attack(villain, hero, villainHealth, false);
        }
        checkWinner(heroHealth, villainHealth);
    }

    private int attack(ComicCharacter attacker, ComicCharacter defender, int defenderHealth, boolean isHeroAttack) {
        int attackPower = (int) (Math.random() * 500);
        defenderHealth -= attackPower;
        System.out.println(attacker.getName() + " hits " + defender.getName() + " for " + attackPower + " damage.");
        System.out.println(defender.getName() + " Health: " + defenderHealth + "\n");
        return defenderHealth;
    }

    private void checkWinner(int heroHealth, int villainHealth) {
        if (heroHealth <= 0 && villainHealth <= 0) {
            System.out.println("It's a draw!");
        } else if (heroHealth <= 0) {
            winner = villain;
            loser = hero;
            System.out.println(villain.getName() + " wins!");
        } else {
            winner = hero;
            loser = villain;
            System.out.println(hero.getName() + " wins!");
        }

        if (winner != null) {
            System.out.println("Before the fight: " + winner.getName() + " has " + winner.myListOfFans.size() + " fans.");

            transferFansAfterFight(winner, loser);

            System.out.println("After the fight: " + winner.getName() + " now has " + winner.myListOfFans.size() + " fans.");

            loser.clearAllFans();


            IndividualFight newFight = new IndividualFight(hero, villain);
            newFight.winner = winner;
            newFight.loser = loser;
            singleFightList.add(newFight);
        }
    }

    public ComicCharacter getVillain() {
        return villain;
    }

    public ComicCharacter getHero() {
        return hero;
    }

    public ComicCharacter getWinner() {
        return winner;
    }

    public ComicCharacter getLoser() {
        return loser;
    }

    public static void searchIndividualFight(Scanner scanner) {
        System.out.println("Which characters participated in the fight?");
        String name = scanner.nextLine().trim();
        boolean found = false;

        for (int i = 0; i < singleFightList.size(); i++) {
            IndividualFight fight = singleFightList.get(i);
            if (fight.getHero().getName().equalsIgnoreCase(name) ||
                    fight.getVillain().getName().equalsIgnoreCase(name)) {
                System.out.println(fight.getDetails());
                System.out.println("-----------------------");
                found = true;
            }
        }

        if (!found) {
            System.out.println("No results found for character with name: " + name);
        }
    }

    public static void selectCharactersForFight(List<ComicCharacter> characters, Scanner scanner) {
        ComicCharacter selectedHero = selectHero(characters, scanner);
        ComicCharacter selectedVillain = selectVillain(characters, scanner);
        chooseFightOutcome(selectedHero, selectedVillain, scanner);
    }

    private static ComicCharacter selectHero(List<ComicCharacter> characters, Scanner scanner) {
        ComicCharacter selectedHero = null;
        boolean correctInput = false;
        String selectedHeroId;

        while (!correctInput) {
            Hero.displayAllHeroes(characters);
            System.out.print("Enter the ID of the hero you want to fight with from the list above: ");
            selectedHeroId = scanner.nextLine().toUpperCase();
            for (ComicCharacter hero : characters) {
                if (hero.getId().equals(selectedHeroId) && hero instanceof Hero) {
                    selectedHero = hero;
                    correctInput = true;
                    break;
                }
            }
            if (!correctInput) {
                System.out.println("Error: character not found or wrong ID.");
            } else {
                System.out.println("You have selected: " + selectedHero.getName());
            }
        }
        return selectedHero;
    }

    private static ComicCharacter selectVillain(List<ComicCharacter> characters, Scanner scanner) {
        ComicCharacter selectedVillain = null;
        boolean correctInput = false;
        String selectedVillainId;

        System.out.println("Select a villain for the fight:\n");
        Villain.displayAllVillains(characters);
        while (!correctInput) {
            System.out.print("Enter the ID of the villain you want to fight against from the list above: ");
            selectedVillainId = scanner.nextLine().toUpperCase();
            for (ComicCharacter villain : characters) {
                if (villain.getId().equals(selectedVillainId) && villain instanceof Villain) {
                    selectedVillain = villain;
                    correctInput = true;
                    break;
                }
            }
            if (!correctInput) {
                System.out.println("Error: character not found or wrong ID.");
            } else {
                System.out.println("You have selected: " + selectedVillain.getName());
            }
        }
        return selectedVillain;
    }

    private static void chooseFightOutcome(ComicCharacter selectedHero, ComicCharacter selectedVillain, Scanner scanner) {
        Menu.displayFightOptions(selectedHero, selectedVillain, scanner);
    }

    public String getDetails() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hero: ").append(hero.getName()).append("\n");
        stringBuilder.append("Villain: ").append(villain.getName()).append("\n");
        if (winner == null) {
            stringBuilder.append("This fight hasn't started yet.\n");
        } else {
            stringBuilder.append(winner.getName()).append(" won the fight\n");
        }
        return stringBuilder.toString();
    }
}
