class Weapon extends Gadget {
    private int powerLevel;

    public Weapon(String name, String ID, String description, int powerLevel) {
        super(name, ID, description);
        this.powerLevel = powerLevel;
    }

    @Override
    public void attributes() {
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Description: " + getDescription());
        System.out.println("Power Level: " + powerLevel);
    }
}
