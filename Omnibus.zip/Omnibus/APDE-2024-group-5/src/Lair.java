public class Lair extends Gadget {
    private String location;

    public Lair(String name, String ID, String description, String location) {
        super(name, ID, description);
        this.location = location;
    }

    @Override
    public void attributes() {
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getID());
        System.out.println("Description: " + getDescription());
        System.out.println("Location: " + location);
    }
}

